package com.example.applock;

import android.content.pm.ApplicationInfo;

public class AppInfo {
    public ApplicationInfo info;
    public String label;

}
